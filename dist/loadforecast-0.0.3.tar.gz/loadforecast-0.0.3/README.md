# loadforecast
A package for an easy time series forecasting of an electrical load.

It is necessary to install prophet package manually in order of proper functioning of this package.
For more information about the installation procedure check https://github.com/facebook/prophet
