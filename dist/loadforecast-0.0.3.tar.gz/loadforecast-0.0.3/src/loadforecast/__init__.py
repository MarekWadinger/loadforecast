"""Welcome to LoadForecast"""

from loadforecast.forecaster import LoadProphet

__version__ = '0.0.3'
