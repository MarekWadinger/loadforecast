# Easy Forecast

This is a package for user-friendly forecasting.